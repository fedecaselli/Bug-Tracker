from .main import cli_app 

#Script entry point (path independent)
if __name__ == "__main__":
    #Start Typer CLI application
    cli_app()